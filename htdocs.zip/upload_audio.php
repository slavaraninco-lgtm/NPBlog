<?php
ob_start();
error_reporting(0);
ini_set('display_errors', 0);
require_once __DIR__ . '/security_bootstrap.php';
header('Content-Type: application/json; charset=utf-8');

if (!isset($_FILES['audio'])) {
    if (ob_get_length()) ob_clean();
    echo json_encode(['success' => false, 'error' => 'Файл не был загружен. Возможно, превышен лимит upload_max_filesize или post_max_size в php.ini']);
    exit;
}

$file = $_FILES['audio'];

// Проверяем код ошибки загрузки
if ($file['error'] !== UPLOAD_ERR_OK) {
    $uploadErrors = [
        UPLOAD_ERR_INI_SIZE   => 'Размер файла превышает допустимый лимит (upload_max_filesize в php.ini)',
        UPLOAD_ERR_FORM_SIZE  => 'Размер файла превышает лимит HTML-формы',
        UPLOAD_ERR_PARTIAL    => 'Файл был загружен только частично',
        UPLOAD_ERR_NO_FILE    => 'Файл не был выбран или не загрузился',
        UPLOAD_ERR_NO_TMP_DIR => 'Отсутствует временная папка на сервере',
        UPLOAD_ERR_CANT_WRITE => 'Не удалось записать файл на диск',
        UPLOAD_ERR_EXTENSION  => 'Загрузка файла остановлена PHP-расширением',
    ];
    $errorMsg = isset($uploadErrors[$file['error']]) ? $uploadErrors[$file['error']] : 'Ошибка загрузки аудио (' . $file['error'] . ')';
    if (ob_get_length()) ob_clean();
    echo json_encode(['success' => false, 'error' => $errorMsg]);
    exit;
}

$uploadDir = getDataPath('files/audio/');

// Создаем директорию если её нет
if (!file_exists($uploadDir)) {
    if (!@mkdir($uploadDir, 0777, true)) {
        if (ob_get_length()) ob_clean();
        echo json_encode(['success' => false, 'error' => 'Не удалось создать папку для аудио: ' . $uploadDir . '. Проверьте права доступа.']);
        exit;
    }
}

if (!isDirectoryWritableSafe($uploadDir)) {
    if (ob_get_length()) ob_clean();
    echo json_encode(['success' => false, 'error' => 'Директория для аудио недоступна для записи: ' . $uploadDir]);
    exit;
}

$allowedAudioExts = ['mp3', 'wav', 'ogg', 'm4a', 'aac', 'flac', 'opus'];
$extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
if (!in_array($extension, $allowedAudioExts)) {
    if (ob_get_length()) ob_clean();
    echo json_encode(['success' => false, 'error' => 'Недопустимое расширение аудио файла. Разрешены только: ' . implode(', ', $allowedAudioExts)]);
    exit;
}

// Проверяем тип файла безопасно
$mimeType = '';
if (function_exists('finfo_open')) {
    $finfo = @finfo_open(FILEINFO_MIME_TYPE);
    if ($finfo) {
        $mimeType = @finfo_file($finfo, $file['tmp_name']);
        @finfo_close($finfo);
    }
}
if (empty($mimeType) && function_exists('mime_content_type')) {
    $mimeType = @mime_content_type($file['tmp_name']);
}

$allowedTypes = ['audio/mpeg', 'audio/mp3', 'audio/wav', 'audio/x-wav', 'audio/ogg', 'audio/m4a', 'audio/x-m4a', 'audio/aac', 'audio/flac', 'audio/opus', 'application/ogg', 'application/octet-stream'];
if (!empty($mimeType) && !in_array($mimeType, $allowedTypes)) {
    if (ob_get_length()) ob_clean();
    echo json_encode(['success' => false, 'error' => 'Недопустимый тип файла. Разрешены только аудио файлы.']);
    exit;
}

// Генерируем безопасное имя файла
$baseName = pathinfo($file['name'], PATHINFO_FILENAME);
// Удаляем только опасные символы, сохраняя кириллицу
$safeName = preg_replace('/[^a-zA-Z0-9_\-\.а-яА-ЯёЁ]/u', '_', $baseName);
if (empty($safeName)) {
    $safeName = 'audio_' . uniqid();
}
$fileName = $safeName . '.' . $extension;

// Проверяем, существует ли файл с таким именем
$counter = 1;
while (file_exists($uploadDir . $fileName)) {
    $fileName = $safeName . '_' . $counter . '.' . $extension;
    $counter++;
}

$targetPath = $uploadDir . $fileName;

$saved = @move_uploaded_file($file['tmp_name'], $targetPath);
if (!$saved) {
    // Fallback: copy + unlink for network shares / custom mounts
    if (@copy($file['tmp_name'], $targetPath)) {
        @unlink($file['tmp_name']);
        $saved = true;
    }
}

if ($saved) {
    if (ob_get_length()) ob_clean();
    echo json_encode([
        'success' => true,
        'filename' => $fileName,
        'path' => getDataUrl('files/audio/' . $fileName)
    ]);
} else {
    if (ob_get_length()) ob_clean();
    echo json_encode(['success' => false, 'error' => 'Ошибка при сохранении файла в целевую папку: ' . $targetPath]);
}
?>
