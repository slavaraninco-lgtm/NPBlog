<?php
/**
 * ==============================================================================
 * NPBlog Editor - Модальное окно глобальных параметров
 * ==============================================================================
 * Переписано на новый фреймворк модальных окон (modals/modal.css, modals/modal.js)
 * Поддерживает 11 разделов настроек:
 * 1. Фон статей (фон по умолчанию, режим растягивания, область, Powered by)
 * 2. Вид blog.html (заголовок страницы, фон каталога, мультиблоговая навигация)
 * 3. Автосохранение (интервал, вызов менеджера автосохранений)
 * 4. Внешний вид (AMOLED-тема, плавный курсор, нижняя панель, ширина контента, кастомизация кнопок)
 * 5. Экспериментальные функции (Undo/Redo, Markdown, проверка нумерации, сброс руководства, очистка шаблонов)
 * 6. RSS Виджет (готовый HTML/JS код для вставки на главную)
 * 7. RSS Лента (автогенерация XML feed, base URL, шаблоны элементов)
 * 8. Пути к блогам (мультиблог директории)
 * 9. Безопасность и доступ (защита паролем, ограничение по IP)
 * 10. SEO и соцсети (Open Graph / Twitter meta, базовый URL, дефолтное превью)
 * 11. Язык интерфейса (мгновенное переключение языка)
 * ==============================================================================
 */

if (!isset($availableLanguages)) {
    require_once __DIR__ . '/../lang_helper.php';
    $availableLanguages = getAvailableLanguages();
    $currentLanguage = getCurrentLanguage();
}
?>
<div id="globalSettingsModal" class="modal-overlay" data-size="xl">
    <div class="modal-dialog modal-xl" style="height: 85vh; max-height: 850px; display: flex; flex-direction: column;">
        <!-- Шапка окна -->
        <div class="modal-header">
            <div class="modal-header-start">
                
                <div class="modal-titles">
                    <h3 class="modal-title" data-i18n="settings.title">Параметры</h3>
                    <p class="modal-subtitle" data-i18n="settings.subtitle">Глобальные настройки блога, интерфейса, безопасности и интеграций</p>
                </div>
            </div>
            <div class="modal-header-actions">
                <button type="button" class="modal-close-btn" onclick="closeGlobalSettings()" data-modal-close data-i18n-title="common.close" title="Закрыть">×</button>
            </div>
        </div>

        <!-- Тело: Слева боковая навигация, справа контент разделов -->
        <div class="modal-body" style="padding: 0; display: flex; flex: 1; overflow: hidden;">
            <!-- Навигация слева -->
            <div style="width: 210px; min-width: 210px; background: var(--modal-bg-subtle, rgba(0,0,0,0.03)); border-right: 1px solid var(--border-color); padding: 16px 12px; overflow-y: auto; display: flex; flex-direction: column; gap: 4px;">
                <div style="font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; color: var(--text-color); opacity: 0.5; padding: 4px 8px; margin-bottom: 4px;" data-i18n="settings.nav_title">Навигация</div>
                
                <button type="button" id="nav-btn-backgrounds" onclick="showGlobalSection('backgrounds')" class="global-nav-btn active" data-section="backgrounds" data-i18n="settings.nav_backgrounds" style="display: block; width: 100%; padding: 8px 12px; border: none; border-radius: 8px; cursor: pointer; text-align: left; font-size: 13px; color: var(--text-color); background: transparent; transition: all 0.15s ease;">
                    Фон статей
                </button>
                <button type="button" id="nav-btn-blogview" onclick="showGlobalSection('blogview')" class="global-nav-btn" data-section="blogview" data-i18n="settings.nav_blogview" style="display: block; width: 100%; padding: 8px 12px; border: none; border-radius: 8px; cursor: pointer; text-align: left; font-size: 13px; color: var(--text-color); background: transparent; transition: all 0.15s ease;">
                    Вид blog.html
                </button>
                <button type="button" onclick="showGlobalSection('autosave')" class="global-nav-btn" data-section="autosave" data-i18n="settings.nav_autosave" style="display: block; width: 100%; padding: 8px 12px; border: none; border-radius: 8px; cursor: pointer; text-align: left; font-size: 13px; color: var(--text-color); background: transparent; transition: all 0.15s ease;">
                    Автосохранение
                </button>
                <button type="button" onclick="showGlobalSection('appearance')" class="global-nav-btn" data-section="appearance" data-i18n="settings.nav_appearance" style="display: block; width: 100%; padding: 8px 12px; border: none; border-radius: 8px; cursor: pointer; text-align: left; font-size: 13px; color: var(--text-color); background: transparent; transition: all 0.15s ease;">
                    Внешний вид
                </button>
                <button type="button" onclick="showGlobalSection('experimental')" class="global-nav-btn" data-section="experimental" data-i18n="settings.nav_experimental" style="display: block; width: 100%; padding: 8px 12px; border: none; border-radius: 8px; cursor: pointer; text-align: left; font-size: 13px; color: var(--text-color); background: transparent; transition: all 0.15s ease;">
                    Экспериментальные
                </button>
                <button type="button" onclick="showGlobalSection('rss')" class="global-nav-btn" data-section="rss" data-i18n="settings.nav_rss" style="display: block; width: 100%; padding: 8px 12px; border: none; border-radius: 8px; cursor: pointer; text-align: left; font-size: 13px; color: var(--text-color); background: transparent; transition: all 0.15s ease;">
                    RSS Виджет
                </button>
                <button type="button" id="nav-btn-rss_feed" onclick="showGlobalSection('rss_feed')" class="global-nav-btn" data-section="rss_feed" data-i18n="settings.nav_rss_feed" style="display: block; width: 100%; padding: 8px 12px; border: none; border-radius: 8px; cursor: pointer; text-align: left; font-size: 13px; color: var(--text-color); background: transparent; transition: all 0.15s ease;">
                    RSS Лента
                </button>
                <button type="button" id="nav-btn-paths" onclick="showGlobalSection('paths')" class="global-nav-btn" data-section="paths" data-i18n="settings.nav_paths" style="display: block; width: 100%; padding: 8px 12px; border: none; border-radius: 8px; cursor: pointer; text-align: left; font-size: 13px; color: var(--text-color); background: transparent; transition: all 0.15s ease;">
                    Пути
                </button>
                <button type="button" id="nav-btn-security" onclick="showGlobalSection('security')" class="global-nav-btn" data-section="security" data-i18n="settings.nav_security" style="display: block; width: 100%; padding: 8px 12px; border: none; border-radius: 8px; cursor: pointer; text-align: left; font-size: 13px; color: var(--text-color); background: transparent; transition: all 0.15s ease;">
                    Безопасность
                </button>
                <button type="button" onclick="showGlobalSection('seo')" class="global-nav-btn" data-section="seo" data-i18n="settings.nav_seo" style="display: block; width: 100%; padding: 8px 12px; border: none; border-radius: 8px; cursor: pointer; text-align: left; font-size: 13px; color: var(--text-color); background: transparent; transition: all 0.15s ease;">
                    SEO и соцсети
                </button>
                <button type="button" id="nav-btn-language" onclick="showGlobalSection('language')" class="global-nav-btn" data-section="language" data-i18n="settings.nav_language" style="display: block; width: 100%; padding: 8px 12px; border: none; border-radius: 8px; cursor: pointer; text-align: left; font-size: 13px; color: var(--text-color); background: transparent; transition: all 0.15s ease;">
                    Язык
                </button>
            </div>
            
            <!-- Контент справа -->
            <div style="flex: 1; padding: 24px 28px; overflow-y: auto;">
                <div style="margin-bottom: 20px; padding-bottom: 12px; border-bottom: 1px solid var(--border-color);">
                    <h3 style="margin: 0; color: var(--text-color); font-size: 18px; font-weight: 600;" id="globalSectionTitle" data-i18n="settings.bg_section_title">Фон статей</h3>
                </div>
            
                <!-- Секция 1: Фон статей -->
                <div id="globalSection-backgrounds" class="global-section">
                    <p style="color: var(--text-color); margin-bottom: 20px; opacity: 0.8; font-size: 13px;" data-i18n="settings.bg_desc">Загрузите фоновое изображение, которое будет применяться ко всем статьям по умолчанию.</p>
                    
                    <!-- Текущий глобальный фон -->
                    <div id="currentGlobalBackgroundInfo" style="display: none; margin-bottom: 20px; padding: 16px; border: 1px solid var(--border-color); border-radius: 10px; background: var(--modal-bg-subtle, rgba(0,0,0,0.02));">
                        <p style="color: var(--text-color); margin-bottom: 10px; font-weight: 600; font-size: 13px;" data-i18n="settings.bg_current_title">Текущий глобальный фон:</p>
                        <img id="currentGlobalBackgroundPreview" src="" style="max-width: 200px; max-height: 140px; border: 1px solid var(--border-color); border-radius: 8px; margin-bottom: 10px; object-fit: cover;">
                        <p style="color: var(--text-color); font-size: 13px; margin-bottom: 4px;" id="currentGlobalBackgroundName"></p>
                        <p style="color: var(--text-color); font-size: 12px; opacity: 0.7;" id="currentGlobalBackgroundMode"></p>
                    </div>
                    
                    <div style="margin-bottom: 20px;">
                        <label class="modal-label" for="globalBackgroundInput" data-i18n="settings.bg_image_label">Фоновое изображение:</label>
                        <div class="modal-file-picker" id="globalBackgroundPicker" tabindex="0" style="margin-bottom: 14px;">
                            <input type="file" id="globalBackgroundInput" accept="image/*" style="display: none;">
                            <button type="button" class="modal-btn modal-btn-secondary modal-file-picker-btn" tabindex="-1">
                                <span data-i18n="common.browse">Обзор...</span>
                            </button>
                            <div class="modal-file-picker-info">
                                <span class="modal-file-picker-text" data-i18n="common.no_file_chosen">Файл не выбран</span>
                                <span class="modal-file-picker-size"></span>
                            </div>
                            <button type="button" class="modal-file-picker-clear" title="Сбросить выбор" data-i18n-title="common.clear_selection">✕</button>
                        </div>
                        
                        <label class="modal-label" for="globalBackgroundMode" data-i18n="settings.bg_mode_label">Режим отображения:</label>
                        <select id="globalBackgroundMode" class="modal-select" style="margin-bottom: 14px;">
                            <option value="cover" data-i18n="settings.bg_mode_cover">Растянуть (cover)</option>
                            <option value="contain" data-i18n="settings.bg_mode_contain">По размеру (contain)</option>
                            <option value="repeat" data-i18n="settings.bg_mode_repeat">Замостить (repeat)</option>
                        </select>
                        
                        <label class="modal-label" for="globalBackgroundScope" data-i18n="settings.bg_scope_label">Область фона:</label>
                        <select id="globalBackgroundScope" class="modal-select" style="margin-bottom: 20px;">
                            <option value="content" data-i18n="settings.bg_scope_content">Только статья (920px)</option>
                            <option value="fullpage" data-i18n="settings.bg_scope_fullpage">Вся страница</option>
                        </select>
                        
                        <div style="display: flex; gap: 8px; flex-wrap: wrap;">
                            <button type="button" onclick="uploadGlobalBackground()" class="modal-btn modal-btn-primary" data-i18n="settings.bg_upload_btn">Загрузить фон</button>
                            <button type="button" onclick="removeGlobalBackground()" class="modal-btn modal-btn-secondary" data-i18n="settings.bg_remove_btn">Удалить фон</button>
                        </div>
                    </div>
                    
                    <div style="margin-top: 24px; padding-top: 16px; border-top: 1px solid var(--border-color); margin-bottom: 20px;">
                        <label class="modal-switch-label" style="display: flex; align-items: center; gap: 12px; cursor: pointer; user-select: none; margin-bottom: 0;">
                            <div class="modal-switch-control">
                                <input type="checkbox" id="hidePoweredByCheckbox" onchange="savePoweredBySetting(this.checked)">
                                <span class="modal-switch-slider"></span>
                            </div>
                            <span style="color: var(--text-color); font-weight: 500; font-size: 13.5px;" data-i18n="settings.bg_hide_powered_by">Скрыть надпись "Powered by NPBlog" в статьях</span>
                        </label>
                    </div>
                    
                    <div style="padding: 14px; background: rgba(255, 193, 7, 0.1); border: 1px solid rgba(255, 193, 7, 0.4); border-radius: 8px; margin-top: 20px;">
                        <p style="color: var(--text-color); font-size: 13px; margin: 0; line-height: 1.5;" data-i18n="settings.bg_warning">
                            ⚠️ Глобальный фон применяется ко всем существующим статьям и будет автоматически применяться к новым статьям. Индивидуальные настройки фона статьи имеют приоритет над глобальным фоном.
                        </p>
                    </div>
                </div>
                
                <!-- Секция 2: Вид blog.html -->
                <div id="globalSection-blogview" class="global-section" style="display: none;">
                    <p style="color: var(--text-color); margin-bottom: 20px; opacity: 0.8; font-size: 13px;" data-i18n="settings.blogview_desc">Настройте внешний вид страницы со списком статей (blog.html).</p>
                    
                    <div style="margin-bottom: 24px; padding-bottom: 20px; border-bottom: 1px solid var(--border-color);">
                        <label class="modal-label" for="blogPageTitle" data-i18n="settings.blogview_page_title_label">Заголовок страницы:</label>
                        <input type="text" id="blogPageTitle" data-i18n-placeholder="settings.blog_title_ph" placeholder="Блог" class="modal-input" style="margin-bottom: 14px;">
                        
                        <button type="button" onclick="saveBlogViewSettings()" class="modal-btn modal-btn-primary" data-i18n="settings.blogview_save_btn">Сохранить настройки</button>
                    </div>

                    <!-- Отображение списка статей (Сетка / Список) -->
                    <div style="margin-bottom: 24px; padding-bottom: 20px; border-bottom: 1px solid var(--border-color);">
                        <h4 style="margin: 0 0 14px 0; color: var(--text-color); font-size: 15px; font-weight: 600;" data-i18n="settings.blogview_layout_title">Отображение списка статей</h4>
                        <label class="modal-label" for="blogPostsLayout" data-i18n="settings.blogview_layout_label">Вид списка статей:</label>
                        <select id="blogPostsLayout" class="modal-select" style="margin-bottom: 14px;">
                            <option value="list" data-i18n="settings.blogview_layout_list">📋 Списком (по умолчанию)</option>
                            <option value="grid" data-i18n="settings.blogview_layout_grid">⊞ Сеткой (карточки с превью)</option>
                        </select>
                        
                        <div style="display: flex; gap: 8px; flex-wrap: wrap;">
                            <button type="button" onclick="saveBlogViewLayout('save')" class="modal-btn modal-btn-primary" data-i18n="settings.blogview_save_layout_current">Сохранить для текущего блога</button>
                            <button type="button" onclick="saveBlogViewLayout('apply_all')" class="modal-btn modal-btn-secondary" data-i18n="settings.blogview_apply_layout_all">Применить во всех блогах</button>
                        </div>
                    </div>

                    <div style="margin-bottom: 20px;">
                        <h4 style="margin: 0 0 14px 0; color: var(--text-color); font-size: 15px; font-weight: 600;" data-i18n="settings.blogview_bg_title">Фон страницы списка статей (blog.html)</h4>
                        
                        <!-- Текущий фон blog.html -->
                        <div id="currentBlogBackgroundInfo" style="display: none; margin-bottom: 20px; padding: 16px; border: 1px solid var(--border-color); border-radius: 10px; background: var(--modal-bg-subtle, rgba(0,0,0,0.02));">
                            <p style="color: var(--text-color); margin-bottom: 10px; font-weight: 600; font-size: 13px;" data-i18n="settings.blogview_current_bg">Текущий фон списка статей:</p>
                            <img id="currentBlogBackgroundPreview" src="" style="max-width: 200px; max-height: 140px; border: 1px solid var(--border-color); border-radius: 8px; margin-bottom: 10px; object-fit: cover;">
                            <p style="color: var(--text-color); font-size: 13px; margin-bottom: 4px;" id="currentBlogBackgroundName"></p>
                            <p style="color: var(--text-color); font-size: 12px; opacity: 0.7;" id="currentBlogBackgroundMode"></p>
                        </div>

                        <label class="modal-label" for="blogBackgroundInput" data-i18n="settings.bg_image_label">Фоновое изображение:</label>
                        <div class="modal-file-picker" id="blogBackgroundPicker" tabindex="0" style="margin-bottom: 14px;">
                            <input type="file" id="blogBackgroundInput" accept="image/*" style="display: none;">
                            <button type="button" class="modal-btn modal-btn-secondary modal-file-picker-btn" tabindex="-1">
                                <span data-i18n="common.browse">Обзор...</span>
                            </button>
                            <div class="modal-file-picker-info">
                                <span class="modal-file-picker-text" data-i18n="common.no_file_chosen">Файл не выбран</span>
                                <span class="modal-file-picker-size"></span>
                            </div>
                            <button type="button" class="modal-file-picker-clear" title="Сбросить выбор" data-i18n-title="common.clear_selection">✕</button>
                        </div>
                        
                        <label class="modal-label" for="blogBackgroundMode" data-i18n="settings.bg_mode_label">Режим отображения:</label>
                        <select id="blogBackgroundMode" class="modal-select" style="margin-bottom: 20px;">
                            <option value="cover" data-i18n="settings.bg_mode_cover">Растянуть (cover)</option>
                            <option value="contain" data-i18n="settings.bg_mode_contain">По размеру (contain)</option>
                            <option value="repeat" data-i18n="settings.bg_mode_repeat">Замостить (repeat)</option>
                        </select>

                        <div style="display: flex; gap: 8px; flex-wrap: wrap;">
                            <button type="button" onclick="uploadBlogBackground()" class="modal-btn modal-btn-primary" data-i18n="settings.bg_upload_btn">Загрузить фон</button>
                            <button type="button" onclick="removeBlogBackground()" class="modal-btn modal-btn-secondary" data-i18n="settings.bg_remove_btn">Удалить фон</button>
                        </div>
                    </div>

                    <div style="margin-top: 28px; padding-top: 20px; border-top: 1px solid var(--border-color);">
                        <h4 style="margin: 0 0 14px 0; color: var(--text-color); font-size: 15px; font-weight: 600;" data-i18n="settings.blogview_crossblog_title">Навигация между блогами</h4>
                        
                        <div id="crossBlogNavStatus" style="display: none; padding: 12px; background: rgba(255, 193, 7, 0.1); border-left: 4px solid #ffc107; margin-bottom: 15px; color: var(--text-color); font-size: 13px;" data-i18n="settings.blogview_crossblog_not_supported">
                            В этом блоге используется нестандартный шаблон. Вставка кнопок не поддерживается.
                        </div>

                        <div id="crossBlogNavEditor" style="display: none;">
                            <label class="modal-switch-label" style="display: flex; align-items: center; gap: 12px; margin-bottom: 15px; cursor: pointer;">
                                <div class="modal-switch-control">
                                    <input type="checkbox" id="enableCrossBlogNav" onchange="toggleCrossBlogNavUI()">
                                    <span class="modal-switch-slider"></span>
                                </div>
                                <span style="color: var(--text-color); font-weight: 500; font-size: 14px;" data-i18n="settings.blogview_crossblog_enable">Кнопки к разным блогам</span>
                            </label>
                            
                            <div id="crossBlogNavList" style="display: none; margin-bottom: 15px; padding: 16px; border: 1px solid var(--border-color); border-radius: 10px; background: var(--modal-bg-subtle, rgba(0,0,0,0.02));">
                                <p style="margin-bottom: 12px; opacity: 0.7; font-size: 13px;" data-i18n="settings.blogview_crossblog_hint">Добавьте кнопки, которые будут отображаться в шапке blog.html для быстрого перехода к другим вашим блогам.</p>
                                <div id="crossBlogNavItems" style="margin-bottom: 15px; display: flex; flex-direction: column; gap: 8px;"></div>
                                <button type="button" onclick="addCrossBlogNavItem()" class="modal-btn modal-btn-secondary" style="font-size: 12px;" data-i18n="settings.blogview_add_btn">+ Добавить кнопку</button>
                            </div>

                            <div style="display: flex; gap: 8px; flex-wrap: wrap;">
                                <button type="button" onclick="saveCrossBlogNav('save')" class="modal-btn modal-btn-primary" data-i18n="settings.blogview_save_current">Сохранить для текущего блога</button>
                                <button type="button" onclick="saveCrossBlogNav('apply_all')" class="modal-btn modal-btn-secondary" data-i18n="settings.blogview_apply_all">Применить во всех блогах</button>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Секция 3: Автосохранение -->
                <div id="globalSection-autosave" class="global-section" style="display: none;">
                    <p style="color: var(--text-color); margin-bottom: 20px; opacity: 0.8; font-size: 13px;" data-i18n="settings.autosave_desc">Настройте автоматическое сохранение статей во время редактирования.</p>
                    
                    <div style="margin-bottom: 20px;">
                        <label class="modal-switch-label" style="display: flex; align-items: center; gap: 12px; margin-bottom: 18px; cursor: pointer;">
                            <div class="modal-switch-control">
                                <input type="checkbox" id="autosaveEnabled" onchange="toggleAutosavePreview()">
                                <span class="modal-switch-slider"></span>
                            </div>
                            <span style="color: var(--text-color); font-weight: 500; font-size: 14px;" data-i18n="settings.autosave_enable">Включить автосохранение</span>
                        </label>
                        
                        <label class="modal-label" for="autosaveInterval" data-i18n="settings.autosave_interval_label">Интервал автосохранения (секунды):</label>
                        <input type="number" id="autosaveInterval" min="10" max="600" value="60" class="modal-input" style="margin-bottom: 20px;">
                        
                        <div style="display: flex; gap: 8px; flex-wrap: wrap;">
                            <button type="button" onclick="saveAutosaveSettings()" class="modal-btn modal-btn-primary" data-i18n="settings.autosave_save_btn">Сохранить настройки</button>
                            <button type="button" onclick="openAutosaveManager()" class="modal-btn modal-btn-secondary" data-i18n="settings.autosave_manager_btn">Менеджер автосохранений</button>
                        </div>
                    </div>

                    <div style="padding: 14px; background: rgba(33, 150, 243, 0.1); border: 1px solid rgba(33, 150, 243, 0.3); border-radius: 8px; margin-top: 20px;">
                        <p style="color: var(--text-color); font-size: 13px; margin: 0; line-height: 1.5;" data-i18n="settings.autosave_hint">
                            💡 Автосохранение создает резервную копию вашей работы через заданный интервал времени. Все автосохранения доступны в менеджере.
                        </p>
                    </div>
                </div>
                
                <!-- Секция 4: Внешний вид -->
                <div id="globalSection-appearance" class="global-section" style="display: none;">
                    <p style="color: var(--text-color); margin-bottom: 20px; opacity: 0.8; font-size: 13px;" data-i18n="settings.appearance_desc">Настройте внешний вид редактора статей.</p>
                    
                    <div style="display: flex; flex-direction: column; gap: 14px; margin-bottom: 20px;">
                        <label class="modal-switch-label" style="display: flex; align-items: center; gap: 12px; cursor: pointer; margin-bottom: 0;">
                            <div class="modal-switch-control">
                                <input type="checkbox" id="amoledTheme">
                                <span class="modal-switch-slider"></span>
                            </div>
                            <span style="color: var(--text-color); font-weight: 500; font-size: 14px;" data-i18n="settings.app_amoled">Включить абсолютно черный фон (для AMOLED дисплеев)</span>
                        </label>
                        
                        <label class="modal-switch-label" style="display: flex; align-items: center; gap: 12px; cursor: pointer; margin-bottom: 0;">
                            <div class="modal-switch-control">
                                <input type="checkbox" id="smoothTyping">
                                <span class="modal-switch-slider"></span>
                            </div>
                            <span style="color: var(--text-color); font-weight: 500; font-size: 14px;" data-i18n="settings.app_smooth_typing">Включить плавную печать текста (мягкий курсор)</span>
                        </label>
                        
                        <label class="modal-switch-label" style="display: flex; align-items: center; gap: 12px; cursor: pointer; margin-bottom: 0;">
                            <div class="modal-switch-control">
                                <input type="checkbox" id="headerBottomPosition">
                                <span class="modal-switch-slider"></span>
                            </div>
                            <span style="color: var(--text-color); font-weight: 500; font-size: 14px;" data-i18n="settings.app_header_bottom">Переместить панель управления в низ экрана</span>
                        </label>

                        <div style="margin-top: 6px;">
                            <label class="modal-label" for="settingsContentWidth" data-i18n="settings.app_content_width">Ширина поля контента (в пикселях):</label>
                            <input type="number" id="settingsContentWidth" min="400" max="2500" placeholder="920" class="modal-input" style="max-width: 250px;">
                        </div>
                        
                        <div style="display: flex; gap: 8px; flex-wrap: wrap; margin-top: 8px;">
                            <button type="button" onclick="saveAppearanceSettings()" class="modal-btn modal-btn-primary" data-i18n="settings.app_save_btn">Сохранить настройки</button>
                            <button type="button" onclick="startHeaderCustomization()" class="modal-btn modal-btn-secondary" data-i18n="settings.app_customize_header_btn">Кастомизация верхней панели</button>
                            <button type="button" onclick="closeGlobalSettings(); openBottomBarCustomizer();" class="modal-btn modal-btn-secondary" data-i18n="bottom_bar.customize">Настроить панель</button>
                        </div>
                    </div>
                    
                    <div style="padding: 14px; background: rgba(33, 150, 243, 0.1); border: 1px solid rgba(33, 150, 243, 0.3); border-radius: 8px; margin-top: 20px;">
                        <p style="color: var(--text-color); font-size: 13px; margin: 0; line-height: 1.5;" data-i18n="settings.app_hint">
                            💡 При скрытии кнопок переключения режимов редактор будет работать только в визуальном режиме.
                        </p>
                    </div>
                </div>
                
                <!-- Секция 5: Экспериментальные функции -->
                <div id="globalSection-experimental" class="global-section" style="display: none;">
                    <p style="color: var(--text-color); margin-bottom: 20px; opacity: 0.8; font-size: 13px;" data-i18n="settings.exp_desc">Включите или отключите экспериментальные функции редактора.</p>
                    
                    <div style="margin-bottom: 24px; padding-bottom: 20px; border-bottom: 1px solid var(--border-color);">
                        <div style="display: flex; flex-direction: column; gap: 14px; margin-bottom: 18px;">
                            <label class="modal-switch-label" style="display: flex; align-items: center; gap: 12px; cursor: pointer; margin-bottom: 0;">
                                <div class="modal-switch-control">
                                    <input type="checkbox" id="enableUndoRedo">
                                    <span class="modal-switch-slider"></span>
                                </div>
                                <span style="color: var(--text-color); font-weight: 500; font-size: 14px;" data-i18n="settings.exp_undo_redo">Включить Undo/Redo (отмена/возврат изменений)</span>
                            </label>
                            
                            <label class="modal-switch-label" style="display: flex; align-items: center; gap: 12px; cursor: pointer; margin-bottom: 0;">
                                <div class="modal-switch-control">
                                    <input type="checkbox" id="enableMarkdown">
                                    <span class="modal-switch-slider"></span>
                                </div>
                                <span style="color: var(--text-color); font-weight: 500; font-size: 14px;" data-i18n="settings.exp_markdown">Использовать Markdown</span>
                            </label>
                            
                            <label class="modal-switch-label" style="display: flex; align-items: flex-start; gap: 12px; cursor: pointer; margin-bottom: 0;">
                                <div class="modal-switch-control" style="margin-top: 2px;">
                                    <input type="checkbox" id="enableApi">
                                    <span class="modal-switch-slider"></span>
                                </div>
                                <div>
                                    <span style="color: var(--text-color); font-weight: 500; font-size: 14px; display: block;" data-i18n="settings.exp_enable_api">Включить REST API (мобильные приложения и сторонние редакторы)</span>
                                    <span style="color: var(--text-color); font-size: 12px; opacity: 0.7; display: block; margin-top: 3px;" data-i18n="settings.exp_enable_api_desc">Разрешает доступ к эндпоинтам /api/v1/... Снимите флажок, чтобы полностью отключить API в целях безопасности.</span>
                                </div>
                            </label>
                        </div>
                        
                        <button type="button" onclick="saveExperimentalSettings()" class="modal-btn modal-btn-primary" data-i18n="settings.exp_save_btn">Сохранить настройки</button>
                    </div>

                    <div style="margin-bottom: 20px;">
                        <h4 style="margin: 0 0 12px 0; color: var(--text-color); font-size: 15px; font-weight: 600;" data-i18n="settings.exp_maint_title">Обслуживание и обучение</h4>
                        <p style="color: var(--text-color); margin-bottom: 14px; opacity: 0.8; font-size: 13px;" data-i18n="settings.exp_maint_desc">Запустите проверку целостности или сбросьте интерактивное руководство.</p>
                        <div style="display: flex; gap: 8px; flex-wrap: wrap;">
                            <button type="button" onclick="checkPostNumbering()" class="modal-btn modal-btn-primary" data-i18n="settings.exp_check_num_btn">Проверка нумерации</button>
                            <button type="button" onclick="resetTutorial()" class="modal-btn modal-btn-secondary" data-i18n="settings.exp_reset_guide_btn">Сбросить обучение</button>
                            <button type="button" onclick="closeGlobalSettings(); openInitialSetupModal();" class="modal-btn modal-btn-secondary" data-i18n="setup.rerun_setup_btn">🚀 Первоначальная настройка</button>
                            <button type="button" onclick="closeGlobalSettings(); openUpdateSuccessNoticeModal();" class="modal-btn modal-btn-secondary" data-i18n="settings.exp_test_update_modal_btn">🎉 Окно обновления (тест)</button>
                            <button type="button" onclick="closeGlobalSettings(); enterSafeMode('Тестовый запуск Safe Mode (проверка интерфейса аварийного восстановления)');" class="modal-btn modal-btn-secondary" style="color: #ef4444; border-color: rgba(239, 68, 68, 0.4);">🛡️ Safe Mode</button>
                            <button type="button" onclick="deleteAllCustomTemplates()" class="modal-btn modal-btn-danger" data-i18n="settings.exp_delete_templates_btn">Удалить кастомные шаблоны</button>
                            <button type="button" onclick="confirmResetAllSettings()" class="modal-btn modal-btn-danger" style="background: rgba(239, 68, 68, 0.12); border-color: rgba(239, 68, 68, 0.35); color: #ef4444;" data-i18n="settings.exp_reset_all_btn">Сбросить все настройки</button>
                        </div>
                    </div>
                    
                    <div style="padding: 14px; background: rgba(255, 152, 0, 0.1); border: 1px solid rgba(255, 152, 0, 0.4); border-radius: 8px; margin-top: 20px;">
                        <p style="color: var(--text-color); font-size: 13px; margin: 0; line-height: 1.5;" data-i18n="settings.exp_warning">
                            ⚠️ Экспериментальные функции могут работать нестабильно. Используйте на свой риск.
                        </p>
                    </div>
                </div>
                
                <!-- Секция 6: Интеграция RSS (Виджет) -->
                <div id="globalSection-rss" class="global-section" style="display: none;">
                    <p style="color: var(--text-color); margin-bottom: 20px; opacity: 0.8; font-size: 13px;" data-i18n="settings.rss_desc">
                        Получите готовый код интерактивного виджета RSS ленты для вставки на главную страницу вашего сайта
                    </p>
                    
                    <!-- Интерактивное превью виджета -->
                    <div style="margin-bottom: 20px; padding: 16px; background: var(--modal-bg-subtle, rgba(0,0,0,0.02)); border: 1px dashed var(--border-color); border-radius: 10px;">
                        <span style="display: block; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; color: var(--text-color); opacity: 0.5; margin-bottom: 8px;" data-i18n="settings.rss_preview_title">Вид виджета</span>
                        <div id="rssLivePreviewContainer" style="min-height: 44px; display: flex; align-items: center;">
                            <div style="font-size: 13px; color: var(--text-color); opacity: 0.6; font-style: italic;" data-i18n="settings.rss_preview_loading">Загрузка превью виджета...</div>
                        </div>
                    </div>

                    <!-- Поля с кодом для вставки -->
                    <div style="display: flex; flex-direction: column; gap: 16px; margin-bottom: 20px;">
                        <!-- Шаг 1: HTML код -->
                        <div style="display: flex; flex-direction: column; gap: 6px;">
                            <div style="display: flex; justify-content: space-between; align-items: center;">
                                <label class="modal-label" for="rssHtmlCode" style="margin: 0;" data-i18n="settings.rss_step1_label">Шаг 1: Вставьте этот HTML-код в место вывода виджета</label>
                                <button type="button" onclick="copyToClipboard('rssHtmlCode', this)" class="modal-btn modal-btn-secondary" style="padding: 4px 10px; font-size: 11px;" data-i18n="settings.rss_copy_html_btn">Копировать HTML</button>
                            </div>
                            <textarea id="rssHtmlCode" readonly class="modal-textarea" style="height: 60px; font-family: Consolas, Monaco, monospace; font-size: 12px; resize: none;"></textarea>
                        </div>

                        <!-- Шаг 2: JS код -->
                        <div style="display: flex; flex-direction: column; gap: 6px;">
                            <div style="display: flex; justify-content: space-between; align-items: center;">
                                <label class="modal-label" for="rssJsCode" style="margin: 0;" data-i18n="settings.rss_step2_label">Шаг 2: Вставьте этот JS-код в конец страницы (перед &lt;/body&gt;)</label>
                                <button type="button" onclick="copyToClipboard('rssJsCode', this)" class="modal-btn modal-btn-secondary" style="padding: 4px 10px; font-size: 11px;" data-i18n="settings.rss_copy_js_btn">Копировать JS</button>
                            </div>
                            <textarea id="rssJsCode" readonly class="modal-textarea" style="height: 240px; font-family: Consolas, Monaco, monospace; font-size: 12px; resize: none;"></textarea>
                        </div>
                    </div>

                    <div style="padding: 14px; background: rgba(33, 150, 243, 0.1); border: 1px solid rgba(33, 150, 243, 0.3); border-radius: 8px; margin-top: 20px;">
                        <p style="color: var(--text-color); font-size: 13px; margin: 0; line-height: 1.5;" data-i18n-html="settings.rss_styling_tip">
                            💡 <strong>Совет по стилизации:</strong> Вы можете полностью изменить внешний вид ссылки виджета на вашем сайте с помощью CSS стилей для класса <code>.npblog-rss-link</code>, прописав его в файле стилей вашего сайта.
                        </p>
                    </div>
                </div>
                
                <!-- Секция 7: RSS Лента (XML) -->
                <div id="globalSection-rss_feed" class="global-section" style="display: none;">
                    <p style="color: var(--text-color); margin-bottom: 20px; opacity: 0.8; font-size: 13px;" data-i18n="settings.rss_feed_desc">Настройте автоматическую генерацию RSS ленты (XML-файла) для вашего блога.</p>
                    
                    <div style="margin-bottom: 20px; padding-bottom: 16px; border-bottom: 1px solid var(--border-color);">
                        <label class="modal-switch-label" style="display: flex; align-items: center; gap: 12px; cursor: pointer; margin-bottom: 8px;">
                            <div class="modal-switch-control">
                                <input type="checkbox" id="rssFeedEnabled">
                                <span class="modal-switch-slider"></span>
                            </div>
                            <span style="color: var(--text-color); font-weight: 500; font-size: 14px;" data-i18n="settings.rss_feed_enable">Включить автоматическую генерацию RSS</span>
                        </label>
                        <p style="color: var(--text-color); opacity: 0.7; font-size: 12px; margin: 0; padding-left: 52px;" data-i18n-html="settings.rss_feed_enable_hint">
                            Если включено, файл <code>feed.xml</code> будет создаваться и обновляться автоматически в корне папки <code>data</code> при сохранении/редактировании/удалении статей.
                        </p>
                    </div>
                    
                    <div id="rssFeedSettingsDetails" style="display: none;">
                        <div style="margin-bottom: 16px;">
                            <label class="modal-label" for="rssFeedBaseUrl" data-i18n="settings.rss_feed_base_url_label">Базовый URL сайта (Base URL):</label>
                            <input type="text" id="rssFeedBaseUrl" placeholder="https://myblog.ru" class="modal-input">
                            <p style="color: var(--text-color); opacity: 0.7; font-size: 12px; margin-top: 4px;" data-i18n-html="settings.rss_feed_base_url_hint">
                                Необходим для формирования абсолютных URL-ссылок на ваши статьи в RSS-ленте (например, <code>https://myblog.ru</code>).
                            </p>
                        </div>

                        <div style="margin-bottom: 16px;">
                            <label class="modal-label" for="rssFeedTitle" data-i18n="settings.rss_feed_title_label">Название RSS-канала (Title):</label>
                            <input type="text" id="rssFeedTitle" placeholder="NPBlog Feed" class="modal-input">
                        </div>

                        <div style="margin-bottom: 16px;">
                            <label class="modal-label" for="rssFeedDescription" data-i18n="settings.rss_feed_desc_label">Описание RSS-канала (Description):</label>
                            <input type="text" id="rssFeedDescription" placeholder="NPBlog RSS Feed" class="modal-input">
                        </div>
                        
                        <div style="margin-bottom: 16px; padding-bottom: 16px; border-bottom: 1px solid var(--border-color);">
                            <label class="modal-switch-label" style="display: flex; align-items: center; gap: 12px; cursor: pointer; margin-bottom: 6px;">
                                <div class="modal-switch-control">
                                    <input type="checkbox" id="rssFeedUseFirstLine">
                                    <span class="modal-switch-slider"></span>
                                </div>
                                <span style="color: var(--text-color); font-weight: 500; font-size: 14px;" data-i18n="settings.rss_feed_first_line">Брать только первую строку статьи в описание</span>
                            </label>
                            <p style="color: var(--text-color); opacity: 0.7; font-size: 12px; margin: 0; padding-left: 52px;" data-i18n="settings.rss_feed_first_line_hint">
                                Если включено, в содержание поста для RSS будет попадать только первая текстовая строка. Если выключено — будет передаваться весь HTML-код содержимого статьи.
                            </p>
                        </div>

                        <div style="margin-bottom: 20px;">
                            <label class="modal-label" for="rssFeedContentTemplate" data-i18n="settings.rss_feed_template_label">Шаблон содержания элемента фида:</label>
                            <textarea id="rssFeedContentTemplate" class="modal-textarea" style="height: 100px; font-family: Consolas, Monaco, monospace; font-size: 12px;"></textarea>
                            <p style="color: var(--text-color); opacity: 0.7; font-size: 12px; margin-top: 6px; line-height: 1.4;" data-i18n-html="settings.rss_feed_template_hint">
                                Используйте плейсхолдеры для подстановки данных:<br>
                                <code>*content*</code> — Текст/HTML статьи (вся статья или только первая строка в зависимости от настройки выше).<br>
                                <code>*url*</code> — Полная ссылка на статью в блоге.
                            </p>
                        </div>
                    </div>

                    <div style="margin-bottom: 20px;">
                        <button type="button" onclick="saveRssFeedSettings()" class="modal-btn modal-btn-primary" data-i18n="settings.rss_feed_save_btn">Сохранить настройки RSS</button>
                    </div>
                </div>

                <!-- Секция 8: Пути -->
                <div id="globalSection-paths" class="global-section" style="display: none;">
                    <p style="color: var(--text-color); margin-bottom: 20px; opacity: 0.8; font-size: 13px;" data-i18n="settings.paths_desc">Настройте пути к директориям блогов, резервных копий и автосохранений на сервере.</p>
                    
                    <!-- Подсекция 1: Директории блогов (data) -->
                    <div style="margin-bottom: 24px; padding-bottom: 20px; border-bottom: 1px solid var(--border-color);">
                        <h4 style="margin: 0 0 8px 0; color: var(--text-color); font-size: 15px; font-weight: 600; display: flex; align-items: center; gap: 8px;">
                            <span data-i18n="settings.paths_blog_dirs_title">Директории блогов (data)</span>
                        </h4>
                        <p style="color: var(--text-color); opacity: 0.75; font-size: 12px; margin-bottom: 14px;" data-i18n="settings.paths_blog_dirs_hint">
                            Укажите пути к папкам данных блогов. При наличии нескольких блогов переключение доступно в нижней панели редактора.
                        </p>
                        <div id="blogPathsListContainer" style="margin-bottom: 14px; display: flex; flex-direction: column; gap: 8px;">
                            <!-- Динамически заполняется через JS -->
                        </div>
                        <div style="display: flex; gap: 10px; align-items: center; flex-wrap: wrap;">
                            <button type="button" onclick="addBlogPathRow()" class="modal-btn modal-btn-secondary" style="display: inline-flex; align-items: center; gap: 6px; font-size: 12px;">
                                <span>➕</span> <span data-i18n="settings.paths_add_btn">Добавить путь к блогу</span>
                            </button>
                            <button type="button" onclick="openCreateBlogModal()" class="modal-btn modal-btn-primary" style="display: inline-flex; align-items: center; gap: 6px; font-size: 12px;">
                                <span>✨</span> <span data-i18n="settings.paths_create_blog_btn">Создать блог</span>
                            </button>
                        </div>
                    </div>

                    <!-- Подсекция 2: Директория резервных копий статей (data_backup) -->
                    <div style="margin-bottom: 24px; padding-bottom: 20px; border-bottom: 1px solid var(--border-color);">
                        <h4 style="margin: 0 0 8px 0; color: var(--text-color); font-size: 15px; font-weight: 600; display: flex; align-items: center; gap: 8px;">
                            <span data-i18n="settings.paths_backup_dir_title">Директория для резервных копий статей (data_backup)</span>
                        </h4>
                        <p style="color: var(--text-color); opacity: 0.75; font-size: 12px; margin-bottom: 14px;" data-i18n="settings.paths_backup_dir_hint">
                            Укажите путь к папке на сервере для хранения резервных копий статей (например: C:\xampp\htdocs\data_backup или data_backup). Если оставить пустым, бэкапы сохраняются в стандартную папку data_backup.
                        </p>
                        <div style="display: flex; gap: 8px; align-items: stretch; margin-bottom: 8px;">
                            <input type="text" id="backupPathInput" class="modal-input" placeholder="C:\xampp\htdocs\data_backup или data_backup" data-i18n-placeholder="settings.paths_backup_ph" style="flex: 1; font-family: monospace; font-size: 13px;">
                            <button type="button" onclick="resetBackupPathToDefault()" class="modal-btn modal-btn-secondary" style="white-space: nowrap; padding: 0 16px; font-size: 12px; display: inline-flex; align-items: center; justify-content: center;" data-i18n="settings.paths_backup_default_btn">
                                По умолч.
                            </button>
                        </div>
                        <div style="font-size: 12px; opacity: 0.7; color: var(--text-color); margin-top: 6px;">
                            <span data-i18n="settings.paths_backup_current">Текущее расположение:</span> <code id="currentResolvedBackupPath" style="font-family: monospace; padding: 2px 6px; background: var(--modal-bg-subtle, rgba(0,0,0,0.05)); border-radius: 4px;">...</code>
                        </div>
                    </div>

                    <!-- Подсекция 3: Директория автосохранений и черновиков (autosave) -->
                    <div style="margin-bottom: 24px; padding-bottom: 20px; border-bottom: 1px solid var(--border-color);">
                        <h4 style="margin: 0 0 8px 0; color: var(--text-color); font-size: 15px; font-weight: 600; display: flex; align-items: center; gap: 8px;">
                            <span data-i18n="settings.paths_autosave_dir_title">Директория для автосохранений и черновиков (autosave)</span>
                        </h4>
                        <p style="color: var(--text-color); opacity: 0.75; font-size: 12px; margin-bottom: 14px;" data-i18n="settings.paths_autosave_dir_hint">
                            Укажите путь к папке на сервере для хранения автосохранений и черновиков статей. Если оставить пустым, данные сохраняются в стандартную папку autosave.
                        </p>
                        <div style="display: flex; gap: 8px; align-items: stretch; margin-bottom: 8px;">
                            <input type="text" id="autosavePathInput" class="modal-input" placeholder="C:\xampp\htdocs\autosave или autosave" data-i18n-placeholder="settings.paths_autosave_ph" style="flex: 1; font-family: monospace; font-size: 13px;">
                            <button type="button" onclick="resetAutosavePathToDefault()" class="modal-btn modal-btn-secondary" style="white-space: nowrap; padding: 0 16px; font-size: 12px; display: inline-flex; align-items: center; justify-content: center;" data-i18n="settings.paths_autosave_default_btn">
                                По умолч.
                            </button>
                        </div>
                        <div style="font-size: 12px; opacity: 0.7; color: var(--text-color); margin-top: 6px;">
                            <span data-i18n="settings.paths_autosave_current">Текущее расположение:</span> <code id="currentResolvedAutosavePath" style="font-family: monospace; padding: 2px 6px; background: var(--modal-bg-subtle, rgba(0,0,0,0.05)); border-radius: 4px;">...</code>
                        </div>
                    </div>

                    <!-- Подсекция 4: Директория бэкапов системы (editor_backup) -->
                    <div style="margin-bottom: 24px; padding-bottom: 20px; border-bottom: 1px solid var(--border-color);">
                        <h4 style="margin: 0 0 8px 0; color: var(--text-color); font-size: 15px; font-weight: 600; display: flex; align-items: center; gap: 8px;">
                            <span data-i18n="settings.paths_editor_backup_dir_title">Директория для бэкапов системы и обновлений (editor_backup)</span>
                        </h4>
                        <p style="color: var(--text-color); opacity: 0.75; font-size: 12px; margin-bottom: 14px;" data-i18n="settings.paths_editor_backup_dir_hint">
                            Укажите путь к папке на сервере для хранения архивов бэкапов всей системы перед обновлениями. Если оставить пустым, архивы сохраняются в стандартную папку editor_backup.
                        </p>
                        <div style="display: flex; gap: 8px; align-items: stretch; margin-bottom: 8px;">
                            <input type="text" id="editorBackupPathInput" class="modal-input" placeholder="C:\xampp\htdocs\editor_backup или editor_backup" data-i18n-placeholder="settings.paths_editor_backup_ph" style="flex: 1; font-family: monospace; font-size: 13px;">
                            <button type="button" onclick="resetEditorBackupPathToDefault()" class="modal-btn modal-btn-secondary" style="white-space: nowrap; padding: 0 16px; font-size: 12px; display: inline-flex; align-items: center; justify-content: center;" data-i18n="settings.paths_editor_backup_default_btn">
                                По умолч.
                            </button>
                        </div>
                        <div style="font-size: 12px; opacity: 0.7; color: var(--text-color); margin-top: 6px;">
                            <span data-i18n="settings.paths_editor_backup_current">Текущее расположение:</span> <code id="currentResolvedEditorBackupPath" style="font-family: monospace; padding: 2px 6px; background: var(--modal-bg-subtle, rgba(0,0,0,0.05)); border-radius: 4px;">...</code>
                        </div>
                    </div>

                    <div style="padding: 14px; background: rgba(33, 150, 243, 0.1); border: 1px solid rgba(33, 150, 243, 0.3); border-radius: 8px; margin-bottom: 20px;">
                        <p style="color: var(--text-color); font-size: 13px; margin: 0; line-height: 1.5;" data-i18n-html="settings.paths_hint">
                            💡 Укажите абсолютные или относительные пути к папкам данных, бэкапов статей, автосохранений и бэкапов системы на сервере. При изменении путей новые файлы будут автоматически сохраняться в указанные директории.
                        </p>
                    </div>
                </div>

                <!-- Секция 9: Безопасность и доступ -->
                <div id="globalSection-security" class="global-section" style="display: none;">
                    <p style="color: var(--text-color); margin-bottom: 20px; opacity: 0.8; font-size: 13px;" data-i18n="settings.sec_desc">Настройте параметры безопасности и доступа редактора.</p>
                    
                    <div style="margin-bottom: 18px; padding-bottom: 18px; border-bottom: 1px solid var(--border-color);">
                        <!-- Вариант 1: Пароль не установлен -->
                        <div id="securityPasswordNotSet" style="display: block;">
                            <label class="modal-switch-label" style="display: flex; align-items: center; gap: 12px; margin-bottom: 15px; cursor: pointer;">
                                <div class="modal-switch-control">
                                    <input type="checkbox" id="settingsPasswordEnabled" onchange="togglePasswordFieldsVisibility()">
                                    <span class="modal-switch-slider"></span>
                                </div>
                                <span style="color: var(--text-color); font-weight: 500; font-size: 14px;" data-i18n="settings.sec_pwd_enable">Включить защиту паролем</span>
                            </label>
                            
                            <div id="securityPasswordFields" style="display: none; margin-bottom: 18px; padding: 16px; background: var(--modal-bg-subtle, rgba(0,0,0,0.02)); border: 1px solid var(--border-color); border-radius: 10px;">
                                <div style="margin-bottom: 12px;">
                                    <label class="modal-label" for="settingsNewPassword" data-i18n="settings.sec_pwd_new">Новый пароль:</label>
                                    <input type="password" id="settingsNewPassword" data-i18n-placeholder="settings.new_password_ph" placeholder="Введите новый пароль" class="modal-input">
                                </div>
                                <div>
                                    <label class="modal-label" for="settingsConfirmPassword" data-i18n="settings.sec_pwd_confirm">Подтверждение пароля:</label>
                                    <input type="password" id="settingsConfirmPassword" data-i18n-placeholder="settings.repeat_new_password_ph" placeholder="Повторите новый пароль" class="modal-input">
                                </div>
                            </div>
                        </div>

                        <!-- Вариант 2: Пароль установлен -->
                        <div id="securityPasswordSet" style="display: none;">
                            <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 14px; flex-wrap: wrap; gap: 10px;">
                                <span style="color: var(--text-color); font-weight: 600; font-size: 14px; display: flex; align-items: center; gap: 6px;">
                                    <span>🔒</span> <span data-i18n="settings.sec_pwd_set_label">Пароль установлен</span>
                                </span>
                                <div style="display: flex; gap: 8px;">
                                    <button type="button" onclick="showChangePasswordForm()" class="modal-btn modal-btn-secondary" style="font-size: 12px;" data-i18n="settings.sec_change_pwd_btn">Изменить пароль</button>
                                    <button type="button" onclick="showDisablePasswordForm()" class="modal-btn modal-btn-secondary" style="font-size: 12px; opacity: 0.85;" data-i18n="settings.sec_disable_pwd_btn">Отключить защиту</button>
                                </div>
                            </div>

                            <!-- Форма изменения пароля -->
                            <div id="changePasswordFormContainer" style="display: none; margin-bottom: 16px; padding: 16px; background: var(--modal-bg-subtle, rgba(0,0,0,0.02)); border: 1px solid var(--border-color); border-radius: 10px;">
                                <div style="margin-bottom: 12px;">
                                    <label class="modal-label" for="changeSettingsOldPassword" data-i18n="settings.sec_pwd_old">Старый пароль:</label>
                                    <input type="password" id="changeSettingsOldPassword" data-i18n-placeholder="settings.old_password_ph" placeholder="Введите старый пароль" class="modal-input">
                                </div>
                                <div style="margin-bottom: 12px;">
                                    <label class="modal-label" for="changeSettingsNewPassword" data-i18n="settings.sec_pwd_new">Новый пароль:</label>
                                    <input type="password" id="changeSettingsNewPassword" data-i18n-placeholder="settings.new_password_ph" placeholder="Введите новый пароль" class="modal-input">
                                </div>
                                <div>
                                    <label class="modal-label" for="changeSettingsConfirmPassword" data-i18n="settings.sec_pwd_confirm">Подтверждение нового пароля:</label>
                                    <input type="password" id="changeSettingsConfirmPassword" data-i18n-placeholder="settings.repeat_new_password_ph" placeholder="Повторите новый пароль" class="modal-input">
                                </div>
                            </div>

                            <!-- Форма отключения пароля -->
                            <div id="disablePasswordFormContainer" style="display: none; margin-bottom: 16px; padding: 16px; background: var(--modal-bg-subtle, rgba(0,0,0,0.02)); border: 1px solid var(--border-color); border-radius: 10px;">
                                <div>
                                    <label class="modal-label" for="disableSettingsPassword" data-i18n="settings.sec_pwd_current_to_disable">Введите текущий пароль для отключения защиты:</label>
                                    <input type="password" id="disableSettingsPassword" data-i18n-placeholder="settings.current_password_ph" placeholder="Введите ваш текущий пароль" class="modal-input">
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div style="margin-bottom: 18px; padding-bottom: 18px; border-bottom: 1px solid var(--border-color);">
                        <label class="modal-switch-label" style="display: flex; align-items: center; gap: 12px; cursor: pointer; margin-bottom: 6px;">
                            <div class="modal-switch-control">
                                <input type="checkbox" id="settingsIpWhitelistEnabled">
                                <span class="modal-switch-slider"></span>
                            </div>
                            <span style="color: var(--text-color); font-weight: 500; font-size: 14px;" data-i18n="settings.sec_ip_enable">Ограничить доступ по списку IP (allowed_ips.txt)</span>
                        </label>
                        <p style="color: var(--text-color); opacity: 0.7; font-size: 12px; margin: 0; padding-left: 52px;" data-i18n-html="settings.sec_ip_hint">
                            Если включено, доступ к редактору и всем его функциям будет разрешен только с IP-адресов, перечисленных в файле <code>allowed_ips.txt</code> в корне проекта. При включении ваш текущий IP-адрес будет автоматически добавлен в список, чтобы вы не потеряли доступ.
                        </p>
                    </div>
                    
                    <div style="margin-bottom: 20px;">
                        <button type="button" onclick="saveSecuritySettings()" class="modal-btn modal-btn-primary" data-i18n="settings.sec_save_btn">Сохранить настройки безопасности</button>
                    </div>
                    
                    <div style="padding: 14px; background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(239, 68, 68, 0.3); border-radius: 8px; margin-top: 20px;">
                        <p style="color: var(--text-color); font-size: 13px; margin: 0; line-height: 1.5;" data-i18n-html="settings.sec_notice">
                            ⚠️ <strong>Рекомендация по безопасности:</strong><br>
                            Для предотвращения прямого скачивания конфигурации из браузера, заблокируйте доступ к JSON-файлам в настройках вашего веб-сервера.
                        </p>
                    </div>
                </div>

                <!-- Секция 10: SEO и соцсети -->
                <div id="globalSection-seo" class="global-section" style="display: none;">
                    <p style="color: var(--text-color); margin-bottom: 20px; opacity: 0.8; font-size: 13px;" data-i18n="settings.seo_desc">Настройте метатеги (Open Graph / Twitter Cards) для корректного отображения превью статей в Telegram, Discord и соцсетях.</p>
                    
                    <div style="margin-bottom: 16px;">
                        <label class="modal-label" for="seoBaseUrl" data-i18n="settings.seo_base_url_label">Базовый URL сайта (Base URL):</label>
                        <input type="text" id="seoBaseUrl" placeholder="https://myblog.ru" class="modal-input">
                        <p style="color: var(--text-color); opacity: 0.7; font-size: 12px; margin-top: 4px;" data-i18n-html="settings.seo_base_url_hint">
                            Необходим для генерации абсолютных URL-адресов статей и картинок (например: <code>https://myblog.ru</code>). Без этого соцсети не смогут корректно загрузить картинки.
                        </p>
                    </div>
                    
                    <div style="margin-bottom: 16px;">
                        <label class="modal-label" for="seoDefaultImage" data-i18n="settings.seo_default_img_label">Изображение по умолчанию (URL или путь):</label>
                        <input type="text" id="seoDefaultImage" placeholder="https://myblog.ru/data/default-preview.png" class="modal-input">
                        <p style="color: var(--text-color); opacity: 0.7; font-size: 12px; margin-top: 4px;" data-i18n-html="settings.seo_default_img_hint">
                            Ссылка на изображение, которое будет использоваться для превью, если в статье нет картинок. Может быть абсолютной ссылкой или относительным путем (например: <code>data/default-preview.png</code>).
                        </p>
                    </div>

                    <div style="margin-bottom: 18px;">
                        <label class="modal-label" for="seoDefaultDescription" data-i18n="settings.seo_default_desc_label">Описание по умолчанию (Default Description):</label>
                        <textarea id="seoDefaultDescription" placeholder="Интересные статьи о программировании и технологиях." data-i18n-placeholder="settings.seo_default_desc_ph" class="modal-textarea" style="height: 80px;"></textarea>
                        <p style="color: var(--text-color); opacity: 0.7; font-size: 12px; margin-top: 4px;" data-i18n-html="settings.seo_default_desc_hint">
                            Описание, которое будет использоваться, если статья слишком короткая или не содержит текста.
                        </p>
                    </div>
                    
                    <div style="margin-bottom: 20px; padding: 12px 14px; background: rgba(33, 150, 243, 0.1); border: 1px solid rgba(33, 150, 243, 0.3); border-radius: 8px;">
                        <p style="color: var(--text-color); font-size: 13px; margin: 0; line-height: 1.5;" data-i18n-html="settings.seo_notice">
                            💡 <strong>Обратите внимание:</strong> При сохранении или обновлении статьи метатеги генерируются автоматически на основе её содержимого. Вы также можете перегенерировать метатеги для всех статей с помощью кнопки ниже.
                        </p>
                    </div>

                    <div style="display: flex; gap: 8px; margin-bottom: 20px; flex-wrap: wrap;">
                        <button type="button" onclick="saveSeoSettings()" class="modal-btn modal-btn-primary" data-i18n="settings.seo_save_btn">Сохранить настройки SEO</button>
                        <button type="button" onclick="regenerateAllPostsMeta(this)" class="modal-btn modal-btn-secondary" data-i18n="settings.seo_regen_btn">Перегенерировать метатеги статей</button>
                    </div>
                </div>

                <!-- Секция 11: Язык -->
                <div id="globalSection-language" class="global-section" style="display: none;">
                    <p style="color: var(--text-color); margin-bottom: 20px; opacity: 0.8; font-size: 13px;" data-i18n="settings.lang_desc">Выберите язык интерфейса редактора NPBlog.</p>
                    
                    <div class="lang-search-wrap">
                        <svg class="lang-search-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                            <circle cx="11" cy="11" r="8"></circle>
                            <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                        </svg>
                        <input type="text" id="langSearchInput" onkeyup="filterLanguages()" placeholder="Поиск языка..." data-i18n-placeholder="settings.lang_search" class="lang-search-input">
                    </div>

                    <div id="languageCardsContainer" class="language-cards-container">
                        <?php 
                        $subnames = [
                            'ru' => 'Russian',
                            'en' => 'English',
                            'uk' => 'Ukrainian',
                            'lv' => 'Latvian',
                        ];
                        foreach ($availableLanguages as $l): 
                            $isSel = ($l['code'] === $currentLanguage);
                            $selectedClass = $isSel ? ' is-selected' : '';
                            $nameStr = (string)$l['name'];
                            $langNameLower = htmlspecialchars(function_exists('mb_strtolower') ? mb_strtolower($nameStr, 'UTF-8') : strtolower($nameStr));
                            $codeUpper = strtoupper((string)$l['code']);
                            $subName = isset($subnames[$l['code']]) ? $subnames[$l['code']] : $codeUpper;
                        ?>
                        <div id="langCard-<?php echo htmlspecialchars($l['code']); ?>" data-lang-code="<?php echo htmlspecialchars($l['code']); ?>" data-lang-name="<?php echo $langNameLower; ?>" class="lang-selection-card<?php echo $selectedClass; ?>" onclick="selectLanguageOption('<?php echo htmlspecialchars($l['code']); ?>', true)">
                            <div class="lang-card-left">
                                <div class="lang-code-badge"><?php echo htmlspecialchars($codeUpper); ?></div>
                                <div class="lang-text-group">
                                    <span class="lang-name"><?php echo htmlspecialchars($l['name']); ?></span>
                                    <span class="lang-subname"><?php echo htmlspecialchars($subName); ?></span>
                                </div>
                            </div>
                            <div class="lang-check-indicator">
                                <svg class="lang-check-icon" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
                                    <polyline points="20 6 9 17 4 12"></polyline>
                                </svg>
                            </div>
                            <input type="radio" name="editor_lang_radio" id="langRadio-<?php echo htmlspecialchars($l['code']); ?>" value="<?php echo htmlspecialchars($l['code']); ?>" class="lang-radio-hidden" <?php echo $isSel ? 'checked' : ''; ?> tabindex="-1" aria-hidden="true">
                        </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <script>
                    function filterLanguages() {
                        let input = document.getElementById('langSearchInput').value.toLowerCase().trim();
                        let cards = document.querySelectorAll('.lang-selection-card');
                        cards.forEach(card => {
                            let name = card.getAttribute('data-lang-name') || '';
                            let code = card.getAttribute('data-lang-code') || '';
                            if (name.includes(input) || code.includes(input)) {
                                card.style.display = 'flex';
                            } else {
                                card.style.display = 'none';
                            }
                        });
                    }
                    </script>
                </div>
            </div>
        </div>

        <!-- Подвал -->
        <div class="modal-footer" style="display: flex; justify-content: space-between; align-items: center; width: 100%;">
            <button type="button" onclick="confirmResetAllSettings()" class="modal-btn modal-btn-danger" style="background: rgba(239, 68, 68, 0.12); border-color: rgba(239, 68, 68, 0.35); color: #ef4444;" data-i18n="settings.exp_reset_all_btn" data-i18n-title="settings.exp_reset_all_title" title="Сбросить все настройки редактора к значениям по умолчанию">
                Сбросить настройки
            </button>
            <div style="display: flex; gap: 8px; align-items: center;">
                <button type="button" id="globalPathsSaveBtn" onclick="savePathsSettings()" class="modal-btn modal-btn-primary" data-i18n="settings.paths_save_btn" style="display: none;">
                    Сохранить настройки путей
                </button>
                <button type="button" onclick="closeGlobalSettings()" class="modal-btn modal-btn-ghost" data-modal-close data-i18n="common.close">Закрыть</button>
            </div>
        </div>
    </div>
</div>
