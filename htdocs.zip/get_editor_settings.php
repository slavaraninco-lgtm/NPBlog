<?php
require_once __DIR__ . '/security_bootstrap.php';
require_once __DIR__ . '/lang_helper.php';
header('Content-Type: application/json; charset=utf-8');

$settingsFile = __DIR__ . '/editor_settings.json';

$availableCodes = getAvailableLanguageCodes();
$defaultLang = !empty($availableCodes) ? $availableCodes[0] : 'ru';

$defaults = [
    'hideEditorModeButtons' => false,
    'amoledTheme' => false,
    'enableUndoRedo' => false,
    'smoothTyping' => false,
    'headerBottomPosition' => false,
    'enableMarkdown' => false,
    'enableApi' => true,
    'autosaveEnabled' => false,
    'autosaveInterval' => 60,
    'tutorialCompleted' => false,
    'initial_setup_completed' => false,
    'contentWidth' => 920,
    'blog_paths' => ['/CHANGE/ME'],
    'active_blog_path' => '/CHANGE/ME',
    'backup_path' => '',
    'autosave_path' => '',
    'editor_backup_path' => '',
    'rss_enabled' => false,
    'rss_base_url' => '',
    'rss_title' => 'NPBlog Feed',
    'rss_description' => 'NPBlog RSS Feed',
    'rss_use_first_line' => true,
    'rss_content_template' => "*content*\n\n<p><a href=\"*url*\">Читать в блоге</a></p>",
    'activeTheme' => 'dark',
    'customThemeCss' => '',
    'language' => $defaultLang,
    'password_set' => false,
    'password_enabled' => false,
    'bottomBar' => [
        'showModeToggle' => true,
        'showBlogSelector' => true,
        'showWordCount' => false,
        'showAutosaveBadge' => true
    ]
];

$suggestedDataPath = str_replace('/', DIRECTORY_SEPARATOR, __DIR__ . '/data');

if (file_exists($settingsFile)) {
    $settings = json_decode(file_get_contents($settingsFile), true) ?: [];
    $merged = array_merge($defaults, $settings);
    $hasPassword = !empty($settings['password_hash']);
    $merged['password_set'] = $hasPassword;
    $merged['password_enabled'] = $hasPassword;
    unset($merged['password_hash']);
    $merged['resolved_backup_path'] = getBackupPath();
    $merged['resolved_autosave_path'] = getAutosavePath();
    $merged['resolved_editor_backup_path'] = getEditorBackupPath();
    $merged['app_dir'] = str_replace('/', DIRECTORY_SEPARATOR, __DIR__);
    $merged['suggested_data_path'] = $suggestedDataPath;
    echo json_encode(['success' => true, 'settings' => $merged]);
} else {
    $defaults['resolved_backup_path'] = getBackupPath();
    $defaults['resolved_autosave_path'] = getAutosavePath();
    $defaults['resolved_editor_backup_path'] = getEditorBackupPath();
    $defaults['app_dir'] = str_replace('/', DIRECTORY_SEPARATOR, __DIR__);
    $defaults['suggested_data_path'] = $suggestedDataPath;
    echo json_encode([
        'success' => true, 
        'settings' => $defaults
    ]);
}
?>
